use trainingdb10;
create table employees
(
id integer,
name varchar(50),
salary double
);
insert into employees (id,name,salary) values(101,'Ram',1500.00);
insert into employees (id,name,salary) values(102,'Shradha',2000.00);
insert into employees (id,name,salary) values(103,'John',1800.00);
insert into employees (id,name,salary) values(104,'Rashmi',12000.00);
insert into employees values(105,'Abdul',17000.00);
insert into employees (id,name) values(106,'Nirmal');

select id,name,salary from employees;

select name,salary from employees;

select salary from employees;
select * from employees;
select id as "empid", name as "First Name",salary+100 as"Incremented Saalry" from employees;

select id as "empid", name as "First Name",salary+salary*0.35 as"Incremented Saalry" from employees;

select * from employees where salary >13000;
select * from employees where name ='Shradha';
select * from employees where id =101;
select * from employees where salary >13000 and salary<180000;
select * from employees where salary between 13000 and 18000;
select * from employees where salary is null;

select * from employees;

update employees set name ='Sobhana' where id=101;
update employees set salary =21000 where id=106;
update employees set name ='De John' ,salary=21000 where id =103;

