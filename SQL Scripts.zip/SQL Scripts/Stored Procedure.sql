
drop procedure printAge;
-- we can give any symbol as delimiter and it is good to use double symbol like //,$$
delimiter $

create procedure printAge()
begin 
	declare age int;
    set age=20;
    select  age;
end$

delimiter ;

call printAge();
drop procedure intro;

delimiter //

create procedure intro()
begin 
		declare no int;
		SET no=0;
    myloop: LOOP
		SET no=no+1;
		
	IF no=10 THEN
		LEAVE myloop;
     END IF;
     END LOOP myloop;    
    select  no;
end//

delimiter ;

call intro();




