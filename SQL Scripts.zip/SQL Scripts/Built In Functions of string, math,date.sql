use trainingdb10;

create table Persons(
PID integer primary key,
NAME varchar(50),
DOB date,
SALARY double,
GENDER char,
CITY varchar(40),
COUNTRY varchar(40)
);

insert into persons values(101,'Meera','1995-07-12',45000.00,'F','PUNE','India'); 
insert into persons values(102,'Mariya','1996-05-13',55000.00,'F','Mumbai','India'); 
insert into persons values(103,'Arun','1991-06-11',85000.00,'M','Paris','UK'); 
insert into persons values(104,'Evan','2000-11-17',25000.00,'M','London','UK'); 
insert into persons values(105,'Manju','1999-12-23',46000.00,'F','New York','USA'); 
insert into persons values(106,'Renju','1997-10-20',78000.00,'F','Manchester','UK'); 
insert into persons values(107,'Vyshak','2001-07-28',35000.00,'M','Kochi','India'); 
insert into persons values(108,'Sudeer','1994-02-15',67000.00,'M','New Jersey','USA'); 
insert into persons values(109,'Anu','1996-11-18',65000.00,'F','Texas','USA'); 
insert into persons values(110,'Eldho','1992-02-13',90000.00,'M','Bangalore','India'); 
insert into persons values(111,'Roshan','2001-06-12',40000.00,'M','Bangalore','India'); 
insert into persons values(112,'Maxon','1995-03-11',68000.00,'M','New Jersey','USA'); 
insert into persons values(113,'Arjun','1996-12-19',55000.00,'M','Texas','USA'); 
insert into persons values(114,'Aneeta','1996-06-17',63000.00,'F','Kochi','India'); 
insert into persons values(115,'Kareena','1993-07-14',75000.00,'F','Manchester','UK'); 


select * from persons;

select name ,dob,salary from persons;
select name ,dob,salary+100 from persons;


-- Inbuilt String functions

select ascii('A');
select ascii(gender) from persons;

select char_length('abcdefgh') ;
select name ,char_length(name) from persons;

select concat ('abc','xyz');
select concat (name ,' ',country) from persons;
select concat_WS ('-',name ,country) from persons;

select format(123456.987,2);
select format(salary,2)from persons;
select insert('welcome to my world',3,10,'to my sql');

select instr('welcome to my world','world');

select country,LCASE(country) from persons;
select LEFT("Welcome to my world",5) ;
select LEFT(name,3) from persons;

select length(name) , length(country)from persons;
select lower(country) from persons;

select length("         welcome to my world");
select length(LTRIM("         welcome to my world"));
Select MID("Welcome to my world !!",5,3);

select position("world" in "Welcome to my world ");
select repeat("JAVA ",10);
select name,repeat(name,3) from persons;
select replace ("who are you?","who","how");

select country,reverse(country) from persons;
select right("Welcome to my world",4);
select right(name ,4)from persons;
select rpad(name,50,"Abc ") from persons;
select length("Welcome to my world      "), length(rtrim("Welcome to my world      "));

select space(10);
select concat(name,space(10),country)from persons;

select strcmp("Anu","Alias");

SELECT substr("Welcome to my world",5,3);
select substr("Welcome to my world" from 5 for 6);

select substring("Welcome to my world",5,5);

select trim("    Welcome    ");

select ucase(name) from persons;
select UPPER(name) from persons;

-- Inbuilt Math functions
select abs(44-55);

select avg(salary) from persons;
select min(salary) from persons;
select max(salary) from persons;
select count(salary) from persons;

select ceil(45.75);
select ceiling(45.75);

select count(name) from persons;

select 10 div 5;
select exp(2);
select floor(25.75);
select greatest(3,12,34,8,35);
select least(3,12,34,8,35);
select pow(4,2);
select rand();
select round(135.375,2);
select sqrt(64);
select truncate(135.375,1); 

-- Date In built  Functions

select curdate();
select current_date();
select current_time();
select current_timestamp();
select curtime();

select date(dob) from persons;
select date("2017-05-14 09:34:21");
select datediff(curdate(),dob)from persons;
select date_add("2024-06-15",interval 10 day);
select date_add("2024-06-15 14:20:00",interval 10 month);
select date_add("2024-06-15 14:20:00",interval 10 hour);
select date_add("2024-06-15 14:20:00",interval 30 week);

select date_format("2024-06-15", "%M %d %Y");
select date_format("2024-06-15", "%W %M %d %Y");
select name,date_format(dob, "%W %M %d %Y") from persons;

select date_sub(curdate(),interval 10 day);
select day(curdate());
select day(dob) from persons;

select dayname("2024-06-15");
select dayname(curdate());

select dayofmonth("2024-06-15");
select dayofweek(curdate());
select dayofyear("2024-06-15");

select extract(month from"2024-06-15");
select extract(week from"2024-06-15");
select extract(quarter from"2024-06-15");

select from_days(678431);
select from_days(24*60*60);
select hour("2024-06-15 09:34:00");
select last_day("2024-06-15");

select makedate(2017,360);
select monthname("2024-06-15");

select now();
select period_add(201703,15);
select quarter("2017-06-15");
select second("2017-06-20 09:34:30.000023");
select subdate("2017-06-15",interval 10 day);
select sysdate();
select weekofyear("2017-06-15");
select year("2017-06-15");
select yearweek("2017-06-15");










