use trainingdb10;

delimiter //

create procedure findSum()
begin 
		declare no int;
        declare sum int;
		SET no=1;
        SET sum=0;
    myloop: LOOP
		SET sum=sum+no;
		SET no=no+1;
		
	IF no=11 THEN
		LEAVE myloop;
     END IF;
     END LOOP myloop;    
    select  sum;
end//

delimiter ;

call findSum();

