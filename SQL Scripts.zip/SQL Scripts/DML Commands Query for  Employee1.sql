use trainingdb10;

select * from employees;
update employees set salary =21000 where id=106;

update employees set name ='De John' ,salary=21000 where id =103;
delete from employees where id=106;
delete from employees where salary >=12000;