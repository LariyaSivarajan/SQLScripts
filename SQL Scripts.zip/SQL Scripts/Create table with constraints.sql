use trainingdb10;
create table students1
(
rollnumber integer primary key,
name varchar(50) not null,
emailid   varchar(50) unique
);
select * from students1;
insert into students1 (rollnumber,name,emailid) values(101,'Arun','arun@gmail.com');
insert into students1 (rollnumber,name,emailid) values(102,'Anju','anju@gmail.com');
insert into students1 (rollnumber,name,emailid) values(103,'Anu','anu@gmail.com');


alter table students_marks1 rename to students1_marks1;

insert into students1 (rollnumber,name,emailid) values(104,'Sumithra','sumi@gmail.com');

insert into students1 (rollnumber,name,emailid) values(105,'raj','raj@gmail.com');