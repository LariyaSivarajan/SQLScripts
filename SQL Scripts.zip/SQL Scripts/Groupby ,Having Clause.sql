use trainingdb10;
describe persons;
select gender ,sum(salary) from persons group by gender; 
select country, gender,sum(salary) from persons group by country,gender order by country;
select country ,count(salary) from persons group by country having country ='India';

select country ,count(salary) from persons group by country having country ='usa';

select country ,count(salary) from persons group by country having country ='uk';

select country , count(pid) as PersonCount from persons group by country having country='India';

select country,gender,count(pid) as MaleCount from persons group by country,gender having country='India' and gender='M';
select country,gender,count(pid) as FemaleCount from persons group by country,gender having country='India' and gender='F';



