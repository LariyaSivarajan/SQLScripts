delimiter //
create function year_difference(p1 date)
returns int deterministic
begin
declare date2 Date;
select curdate()  into  date2 ;
return year(date2)-year(p1);
 end//
delimiter ;

select year_difference(dob) from persons;

drop function year_difference;