-- Join Query

create table customers
(
customer_id int,
customer_name text(50),
customer_email text(50),
customer_phone text(50)
);

create table orders
(
order_id int auto_increment primary key,
order_date date,
order_amount double,
customer_id int
);

insert into customers values(101,"Anu Alias","anu@gmail.com","4378329121");
insert into customers values(102,"Manoj","manoj@gmail.com","3211356621");
insert into customers values(103,"Maya","maya@gmail.com","9876543211");
insert into customers values(104,"Mevin","mevin@gmail.com","2345678222");
insert into customers values(105,"Praveen","praveen@gmail.com","2345687543");

select * from customers;

insert into orders (order_date,order_amount,customer_id) values("2024-03-02",50000.00,111);
insert into orders (order_date,order_amount,customer_id) values("2024-03-03",60000.00,105);
insert into orders (order_date,order_amount,customer_id) values("2024-03-05",2000.00,102);
insert into orders (order_date,order_amount,customer_id) values("2024-03-05",3300.00,104);
insert into orders (order_date,order_amount,customer_id) values("2024-03-06",500.00,112);
insert into orders (order_date,order_amount,customer_id) values("2024-02-06",38700.00,102);
insert into orders (order_date,order_amount,customer_id) values("2024-03-09",64300.00,104);
insert into orders (order_date,order_amount,customer_id) values("2024-03-10",22000.00,105);
insert into orders (order_date,order_amount,customer_id) values("2024-03-11",33300.00,104);
insert into orders (order_date,order_amount,customer_id) values("2024-03-12",50110.00,105);
select * from orders;
drop table orders;

select * from customers ,orders where customers.customer_id=orders.customer_id;
-- inner join

select 
c.customer_id,c.customer_name,c.customer_email,c.customer_phone,
o.order_id,o.order_date,o.order_amount
 from customers c 
 inner join 
 orders o 
 on 
 c.customer_id=o.customer_id;
-- left outer join 
select 
c.customer_id,c.customer_name,c.customer_email,c.customer_phone,
o.order_id,o.order_date,o.order_amount,o.customer_id
 from customers c 
 left join 
 orders o 
 on 
 c.customer_id=o.customer_id;


-- right outer join

select 
c.customer_id,c.customer_name,c.customer_email,c.customer_phone,
o.order_id,o.order_date,o.order_amount,o.customer_id
 from customers c 
 right join 
 orders o 
 on 
 c.customer_id=o.customer_id;


