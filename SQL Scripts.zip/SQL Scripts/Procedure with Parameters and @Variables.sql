use trainingdb10;

delimiter //
create procedure countryCount(in countryName varchar(50),out counter int)
begin
	select count(*) into counter from persons
    where country=countryName;
end//

delimiter ;;
call countryCount ('UK',@cnt);
select @cnt;
drop procedure countryCount;