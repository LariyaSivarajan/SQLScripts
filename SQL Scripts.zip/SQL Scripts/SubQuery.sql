-- Sub Query or Nested Query
use trainingdb10;

select 	name, salary from persons   where 	salary < (select avg(salary) from persons);
        
select name,salary,city	from persons where country in ('USA','UK');