use trainingdb10;

create table PRODUCTS(
pid int,
pname text(50),
pprice double,
pcategory text(50),
constraint product_id_pk primary key (pid),
constraint product_price_ck check(pprice>0)
);

select * from products;