use trainingdb10;
Rename table customers to customer;
create table CUSTOMERS(
CID INT,
NAME TEXT(50) NOT NULL,
BALANCE DOUBLE,
EMAIL TEXT(50) NOT NULL,
PHONENO TEXT(10) NOT NULL,

constraint CUSTOMERS_CID_PK PRIMARY KEY (CID),
constraint CUSTOMERS_BALANCE_CHECK check(BALANCE >0)

);

select * from customers;
DROP TABLE CUSTOMERS;
desc customers;
Select * from customers;
alter table customers 
drop constraint CUSTOMERS_NAME_CHECK;
alter table customers 
modify column email varchar(50) not null,
modify column name varchar(50) not null,
modify column phoneno varchar(50) not null;