use trainingdb3;

create table test3(
id int,
name text
);

desc test3;

alter table test3
add age int;
desc test3;

alter table test3
add (doj date,salart double);

desc test3;



alter table test3 change column salart salary double;


alter table test3
drop doj;
desc test3;


alter table test3
modify column salary int;
desc test3;
