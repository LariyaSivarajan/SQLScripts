use trainingdb10;
select * from persons;

delimiter //
create procedure retrieveName(
IN personId int,
out personName text(50))
begin
select upper(name) into personName from persons where pid=personId;
end//
delimiter ;

call retrieveName(103,@Person);

select @Person;

