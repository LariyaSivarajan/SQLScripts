use trainingdb10;


create table items(
id int auto_increment primary key,
name text,
price double
);

insert into items (name,price) values('DELL',35000);
insert into items (name,price) values('ACER',36000);
insert into items (name,price) values('IPhone',-90000);
insert into items (name,price) values('Samsung',55000);


select * from items; 
select * from items_logs; 

create table items_logs(
id int auto_increment primary key,
name text,
type text,
created_time datetime

);

-- Insert Trigger
delimiter //
create trigger itemBeforeInsert
before insert
on items for each row
begin 

	if(new.price<0)
		then set new.price=0;
	end if;

end//

delimiter ;

drop trigger itemAfterInsert;
-- Trigger After Insert 

delimiter //

create trigger itemAfterInsert
	after insert
		on items for each row
	begin 
	declare temp datetime;
	set temp=now();
	insert into items_logs(name,type,created_time)
	values(new.name ,"Insert",temp);
end //

delimiter ;

-- Trigger After Delete
delimiter //

create trigger itemAfterDelete
	after delete
		on items for each row
	begin 
	declare temp datetime;
	set temp=now();
	insert into items_logs(name,type,created_time)
	values(old.name ,"Delete",temp);
end //

delimiter ;

delete from items where id=5;

delimiter //
create trigger itemAfterUpdate
	after update
		on items for each row
	begin 
	declare temp datetime;
	set temp=now();
	insert into items_logs(name,type,created_time)
	values(old.name ,"Update",temp);
end //

delimiter ;
update items set price=25000 where id=6;

select * from items_logs;
select * from items;


drop trigger itemAfterUpdate;

drop table items_logs;
drop table items;
