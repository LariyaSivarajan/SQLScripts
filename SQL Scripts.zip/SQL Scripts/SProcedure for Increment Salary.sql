drop procedure incrementSalary;
use trainingdb10;

delimiter //

create procedure incrementSalary
(in countryName text(50),
in per int,
out tot double,
out pname text(50))
begin
	update persons
    set salary=(salary+salary*per/100)
    where country=countryName;
    select sum(salary) into tot from persons where country=countryName;
    select @Person into pname;
end //
    delimiter ;
call incrementSalary('UK',5,@total,@personname);
select @total;
select @personname;