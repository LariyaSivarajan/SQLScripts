use trainingdb10;

create table students1_marks1
(
id integer primary key,
rollnumber integer references students1(rollnumber),
subject varchar(50) ,
mark integer check(mark>=0 and mark<=100)  
);

drop table students1_marks1;
drop table students1_marks2;

create table students1_marks2
(
id integer ,
rollnumber integer ,
subject varchar(50) ,
mark integer ,
primary key(id),
foreign key(rollnumber) references students1(rollnumber),
check(mark>=0 and mark<=100)  

);

select * from students1;
describe students1_marks1;
show tables;
use trainingdb10;
select * from students1_marks1;

select * from students1_marks2;

insert into students1_marks2  values(5001,110,'Maths',67);
insert into students1_marks1  values(5002,110,'Physics',76);
insert into students1_marks1  values(5003,101,'Chemistry',86);
insert into students1_marks1  values(5004,103,'Maths',87);
insert into students1_marks1  values(5002,110,'Physics',76);

create table students1_marks3
(
id integer ,
rollnumber integer ,
subject varchar(50) ,
mark integer ,
constraint mark_id_pk primary key(id),
constraint rollnumber_fk foreign key(rollnumber) references students1(rollnumber),
constraint mark_range_check check(mark>=0 and mark<=100)  

);


