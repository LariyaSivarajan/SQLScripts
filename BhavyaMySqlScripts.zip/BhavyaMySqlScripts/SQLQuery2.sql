use trainingdb1;

update employees set name='Kiran' where id=103;

update employees set salary=21000 where id=106;
update employees set name='Rahul', salary=33000 where id=104;

select * from employees;

delete from employees where id=106;
delete from employees where salary>20000;


select * from employees order by name desc;