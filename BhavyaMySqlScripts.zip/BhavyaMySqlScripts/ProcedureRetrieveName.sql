drop procedure retrieveName;
select * from persons;


delimiter //
create procedure retrieveName(
	in personid int,
    out personname varchar(50))
begin
	select ucase(name) into personname from persons where pid=personid;
end //

delimiter ;

call retrieveName(101,@personval);
select @personval;



