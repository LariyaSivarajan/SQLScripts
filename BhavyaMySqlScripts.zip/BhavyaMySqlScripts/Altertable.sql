create table test3(
	id int,
    name text
);
desc test3;

alter table test3 add age int;
alter table test3 add (doj date, salary double);

alter table test3 drop doj;
alter table test3 modify column salary int;