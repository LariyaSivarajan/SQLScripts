create table PERSONS(
				PID integer primary key,
                Name varchar(50),
                DOB date,
				Salary double,
                Gender char,
                City varchar(40),
                Country varchar(40)
                );
                
insert into persons values(101,'Manu','1992-08-21',50000.0,'M','Pune','India');
insert into persons values(102,'Ram','1994-09-03',55000.0,'M','Chennai','India');
insert into persons values(103,'Meenu','1991-02-21',30000.0,'F','Delhi','India');
insert into persons values(104,'Rahul','1997-03-11',66000.0,'M','Bangalore','India');
insert into persons values(105,'Harshad','1993-07-20',90000.0,'M','Pune','India');
insert into persons values(106,'Pranali','1992-03-1',88000.0,'F','Mumbai','India');
insert into persons values(107,'Asha','1993-03-11',55000.0,'F','Pune','India');
insert into persons values(108,'Surya','1992-07-23',66000.0,'M','Chennai','India');
insert into persons values(109,'Amar','1992-02-08',45000.0,'M','Delhi','India');
insert into persons values(110,'Meera','1997-07-21',33600.0,'F','Pune','India');
insert into persons values(111,'Pooja','1996-03-1',38000.0,'F','Mumbai','India');
insert into persons values(112,'Helen','1993-03-11',35000.0,'F','Pune','India');
insert into persons values(113,'George','1994-07-23',76000.0,'M','Chennai','India');
insert into persons values(114,'Mridula','1992-02-17',65000.0,'F','Delhi','India');
insert into persons values(115,'Malavika','1994-07-21',63600.0,'F','Chennai','India');

select * from persons;
select name,dob,salary from persons;
select name,dob,salary+100 from persons;

select ascii('A') ;
select ascii(gender) from persons;
select name, char_length(name) from persons;
select char_length('abcd');
select concat('abc','xyz');
select concat(name,' ',country) as name_country from persons;
select concat_ws('-',name,country) from persons;
select format(123456.789,2);
select format(salary,2) from persons;
select insert('welcome to my world',3,10,"to my Sql");
select instr('welcome to my world','my');
select lcase(name),country,lcase(country) from persons;
select LEFT("welcome to my world",5);
select left(name,3) from persons;
select length('welcome');
select length(name) , length(country) from persons;
select lower(country) from persons;
select lpad(name,30,"abc") from persons;
select length("     welcome to my world");
select length(ltrim("     welcome to my world"));
select MID("Welcome to my world !!",5,3);
select position("world" IN "Welcome to my World");
select name,repeat(name,3) from persons;
select repeat("Java",10);
select replace ("who are you?","who","how");
select country,reverse(country) from persons;
select reverse('who');
select right("Welcome to my world",4);
select right(name,4) from persons;
select rpad(name,50,"Abc ") from persons;
select rtrim("welcome to my world         ");
select concat(name,space(10),country) from persons;
select strcmp("xyz","abc"); 
select strcmp("abc","abc");
select strcmp("abc","xyz");
select substr("Welcome to my world",5,3);
select substr("Welcome to my world"from 5 for 6);
select substring("Welcome to my world",5,5);
select trim("   welcome   ");
select ucase(name) from persons;
select upper(name) from persons;

select abs(45-55);  -- gives the positive value after substraction
select avg(salary) from persons;
select min(salary) from persons;
select max(salary) from persons;
select count(salary) from persons;

select ceil(45.75);
select ceiling(45.75);
select 10 div 5;
select exp(2);
select floor(25.75);
select greatest(3,12,5,44,77,8);
select least(3,12,5,44,77,8);
select pow(4,2);
select rand();
select round(135.375,1);
select sqrt(64);
select truncate(135.375,1);

select curdate();
select current_date();
select current_time();
select current_timestamp();
select curtime();

select date(dob) from persons;
select date ("2017-04-05 09:34:21");
select datediff(dob,curdate()) from persons;
select datediff(curdate(),dob) from persons;

select date_add("2024-06-15",INTERVAL 10 day);
select date_add("2024-06-15 14:30:00",INTERVAL 10 month);
select date_add("2024-06-15 14:30:00",INTERVAL 10 hour);
select date_add("2024-06-15 14:30:00",INTERVAL 10 week);

select date_format("2014-06-15","%M %d %Y");
select date_format("2014-06-15","%W %M %d %Y");
select name,date_format(dob,"%W %M %d %Y") from persons;

select date_sub(curdate(),interval 10 day);
select day(curdate());
select day(dob) from persons;

select dayname("2017-04-05");
select dayname(curdate());

select dayofmonth("2024-04-5");
select dayofweek(curdate());
select dayofyear("2025-07-20");

select extract(month from "2025-07-20");
select extract(week from "2025-07-20");
select extract(quarter from "2025-07-20");

select from_days(685467);
select from_days(24*60*60);
select from_days(0);

select hour("2025-07-20 09:34:00");
select last_day("2017-07-20");
select makedate(2017,365);
select monthname("2025-07-20");

select now();

select period_add(201703,15);
select quarter("2025-07-20");
select second("2025-07-20 09:34:00.000023");
select subdate("2025-07-20",interval 10 day);
select sysdate();
select weekofyear("2025-07-20");
select year("2025-07-20");
select yearweek("2025-07-20");