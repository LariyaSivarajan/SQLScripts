/*create trigger triggername before insert 
on <table> for each row
begin

end*/

create table items( 
	id int auto_increment primary key,
    name text,
    price double
    );
    
insert into items(name,price) values('DELL',35000);
insert into items(name,price) values('ACER',25000);
insert into items(name,price) values('HP',55000);
insert into items(name,price) values('LG',33000);
select * from items;

create table item_logs(
	id int auto_increment primary key,
    name text,
    type text,
    created_time datetime
);

delimiter // 
create trigger itemBeforeInsert
before insert
on items for each row
begin
	if new.price<0
		then set new.price=0;
	end if;
end //

delimiter ;

insert into items(name,price) values('IPhone',-98760.00);
insert into items(name,price) values('Samsung',98760.00);

drop trigger itemAfterInsert;

delimiter //
create trigger itemAfterInsert
after insert
on items for each row
begin
	declare temp datetime;
    set temp=now();
    insert into 
    item_logs(name,type,created_time) 
    values(new.name,"Insert",temp);
end //

delimiter ;        
    
select * from item_logs;
select * from items;

delimiter //
create trigger itemAfterDelete
after delete
on items for each row
begin
	declare temp datetime;
    set temp=now();
    insert into 
    item_logs(name,type,created_time) 
    values(old.name,"Delete",temp);
end //
delimiter ;

delete from items where name='Samsung';

delimiter //
create trigger itemAfterUpdate
after update
on items for each row
begin
	declare temp datetime;
    set temp=now();
    insert into 
    item_logs(name,type,created_time) 
    values(old.name,"Update",temp);
end //
delimiter ;

update items set price=80000 where name='DELL';