drop procedure intro;

delimiter //

create procedure intro()
begin
	declare no INT;
	set no=0;
	myloop: loop
		set no=no+1;
		
		if no=10 then
			leave myloop;
		end if;
	end loop myloop;
	select no;
end//
delimiter ;

call intro();