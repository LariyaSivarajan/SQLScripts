create database trainingdb1;
create database trainingdb3;

use trainingdb1;

create table employees
(
		id integer,
        name varchar(50),
		salary double 
);

describe employees;

insert into employees(id,name,salary) values (101,'Manu',15000.0);
insert into employees(id,name,salary) values (102,'Surya',20000.0);
insert into employees(id,name,salary) values (103,'Meenu',45000.0);
insert into employees(id,name,salary) values (104,'Raji',18000.0);
insert into employees values (105,'Priya',44500.0);
insert into employees(id,name) values (106,'Beena');

select * from employees;

select id,name,salary from employees;
select id,name from employees;

select id as "empid",name as "First Name", salary+100 as "Incremented Salary" from employees;

select * from employees where salary>18000;
select * from employees where name='Manu';
select * from employees where salary>13000 and salary<18000;
select * from employees where salary between 13000 and 40000;
select * from employees where salary is null;

update employees set name='Kiran' where id=103;