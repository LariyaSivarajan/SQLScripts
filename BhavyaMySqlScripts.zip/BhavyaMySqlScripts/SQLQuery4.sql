create table students1(
rollnumber integer primary key,
name varchar(50) not null,
emailid varchar(50) unique
);

insert into students1 values(101,'Manu','Manu@gmail.com');
insert into students1 values(102,'Divya','Divya@gmail.com');
insert into students1 values(103,'Arun','Arun@gmail.com');
insert into students1(rollnumber,name,emailid) values(104,'Surya','Surya@gmail.com');


create table students1_marks1(
id integer primary key,
rollnumber integer references students1(rollNumber),
subject varchar(50),
mark integer check(mark>=0 and mark<=100)
);

create table students1_marks2(
id integer,
rollnumber integer,
subject varchar(50),
primary key(id),
foreign key(rollNumber) references students1(rollNumber),
mark integer check(mark>=0 and mark<=100)
);-- other way to write

insert into students1_marks1 values(5001,101,'Maths',56);
insert into students1_marks1 values(5002,101,'Engish',99);
insert into students1_marks1 values(5003,101,'Physics',77);
insert into students1_marks1 values(5004,102,'Maths',76);

select * from students1_marks1;

desc students1_marks1;
desc students1_marks2;

insert into students1_marks2 values(5001,101,'Maths',56);
insert into students1_marks2 values(5002,101,'Engish',99);
insert into students1_marks2 values(5003,101,'Physics',77);
insert into students1_marks2 values(5004,102,'Maths',76);
insert into students1_marks2 values(5005,103,'Maths',76);

create table students1_marks3(
id integer,
rollnumber integer,
subject varchar(50),
mark integer,
constraint mark_id_pk primary key(id),
constraint rollnumber_fk foreign key(rollNumber) references students1(rollNumber),
constraint mark_range_check check(mark>=0 and mark<=100)
);

desc students1_marks3;

-- delete from students1 where rollnumber=104;

