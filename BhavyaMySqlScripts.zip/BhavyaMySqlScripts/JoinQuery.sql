create table customers(
customer_id int,
customer_name text(50),
customer_email text(50),
customer_phone text(50)
);

create table orders(
order_id int auto_increment primary key,
order_date date,
order_amount double,
customer_id int
);

insert into customers(
customer_id, customer_name,customer_email,customer_phone)values (101,"Manu","Manuvarma@gmail.com","9876543211");
insert into customers(
customer_id, customer_name,customer_email,customer_phone)values (102,"Rahul","Rahul@gmail.com","9832637311");
insert into customers(
customer_id, customer_name,customer_email,customer_phone)values (103,"Kiran","Kiran@gmail.com","9843533991");
insert into customers(
customer_id, customer_name,customer_email,customer_phone)values (104,"Meenu","Meenu@gmail.com","5280263838");
insert into customers(
customer_id, customer_name,customer_email,customer_phone)values (105,"Rani","Rani@gmail.com","8876543211");

insert into orders(
order_date,order_amount,customer_id) values('2023-12-14',45600.0,101);
insert into orders(
order_date,order_amount,customer_id) values('2023-12-16',55600.0,101);
insert into orders(
order_date,order_amount,customer_id) values('2023-11-14',12300.0,102);
insert into orders(
order_date,order_amount,customer_id) values('2023-11-15',88600.0,102);
insert into orders(
order_date,order_amount,customer_id) values('2023-10-4',23600.0,104);
insert into orders(
order_date,order_amount,customer_id) values('2023-10-24',45600.0,104);
insert into orders(
order_date,order_amount,customer_id) values('2023-07-19',45600.0,105);
insert into orders(
order_date,order_amount,customer_id) values('2023-07-29',45600.0,105);
insert into orders(
order_date,order_amount,customer_id) values('2023-02-26',45600.0,106);
insert into orders(
order_date,order_amount,customer_id) values('2023-02-10',45600.0,106);

select * from customers,orders;

select * from customers,orders where customers.customer_id=orders.customer_id;

select c.customer_id,c.customer_name,c.customer_phone,
o.order_id, o.order_date, o.order_amount,o.customer_id
from
Customers c inner join Orders o
on
c.customer_id=o.customer_id;
 
select c.customer_id,c.customer_name,c.customer_phone,
o.order_id, o.order_date, o.order_amount,o.customer_id
from
Customers c left join Orders o
on
c.customer_id=o.customer_id;

select c.customer_id,c.customer_name,c.customer_phone,
o.order_id, o.order_date, o.order_amount,o.customer_id
from
Customers c right join Orders o
on
c.customer_id=o.customer_id;
