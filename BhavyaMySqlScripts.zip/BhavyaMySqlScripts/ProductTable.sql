use trainingdb1;

create table PRODUCTS(
pid	int,
pname	text(50),
pprice 	double,
pcategory	text(50),
constraint product_id_pk primary key(pid),
constraint product_price check(pprice>0)
);

desc products;

select * from products;