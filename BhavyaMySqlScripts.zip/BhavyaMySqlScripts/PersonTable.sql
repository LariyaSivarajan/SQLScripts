desc persons;

select city,sum(salary) from persons group by city;
select avg(salary) from persons group by city;

select avg(salary) from persons;
select city,count(salary) from persons group by city having city="Pune"; 

select city, sum(salary) from persons group by city having city="Mumbai";

select count(pid) from persons group by city having city="Pune";
select count(pid) as Male_count from persons group by gender having gender="M";
select count(pid) as Female_count from persons group by gender having gender="F";

select name,salary from persons where salary>(select avg(salary) from persons);
select name,salary from persons where salary<(select avg(salary) from persons);

select name,salary,city
from persons
where city in ('Pune', 'Chennai');




