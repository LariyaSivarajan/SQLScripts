use trainingdb1;

delimiter //
create procedure countrycount(in countryname varchar(50), out counter int)
begin
	select count(*) into counter from persons
	where country=countryname;
end//
delimiter ;

call countrycount('India',@cnt);
select @cnt;