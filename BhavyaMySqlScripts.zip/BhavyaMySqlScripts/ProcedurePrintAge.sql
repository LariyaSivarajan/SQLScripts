
 delimiter //
 
create procedure printAge()
begin
	declare age int;
    set age=20;
    select age;
end//

delimiter ;

call printAge();