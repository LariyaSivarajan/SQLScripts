-- print the sum of numbers from 1 to 10
-- procedure name findSum()
delimiter //
create procedure findSum()
begin
	declare sum INT;
    declare num int;
	set sum=0;
    set num=1;
	myloop: loop
		set sum=sum+num;
		set num=num+1;	
		if num=11 then
			leave myloop;
		end if;
	end loop myloop;
	select sum;
end//
delimiter ;

call findSum();

drop procedure findSum;