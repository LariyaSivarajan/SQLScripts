use trainingdb1;

create table STUDENTS(
	ROLLNUMBER INT,
    NAME TEXT(50),
    GENDER CHAR(1),
    MARK1 INT,
    MARK2 INT,
    constraint STUDENTS_RN_PK PRIMARY KEY(ROLLNUMBER),
    constraint STUDENTS_GENDER_CHECK check (GENDER='M' OR  GENDER='F'),
    constraint STUDENTS_MARK1_CHECK check(MARK1>=0 AND MARK1<=100),
    constraint STUDENTS_MARK2_CHECK check(MARK2>=0 AND MARK2<=100));

select * from students;
