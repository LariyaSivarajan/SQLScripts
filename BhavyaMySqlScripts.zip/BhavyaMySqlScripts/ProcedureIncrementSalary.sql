use trainingdb1;
drop procedure incrementSalary;
delimiter //
create procedure incrementSalary(
	in cityname text(50),
	in per int,
	out tot double)
begin 
	update persons 
    set salary=(salary+(salary*per/100))
    where city=cityname;
    
    select sum(salary) 
    into tot from persons
    where city=cityname;
    
end //

delimiter ;

call incrementSalary('Pune',5,@total);
select @total;
    
