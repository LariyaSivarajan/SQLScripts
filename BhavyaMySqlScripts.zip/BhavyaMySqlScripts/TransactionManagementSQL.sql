create table test1(
id int,
age int,
grade char(1)
);

set autocommit=off;

insert into test1 values(1,20,'A');
insert into test1 values(2,25,'B');
insert into test1 values(3,26,'A');

select * from test1;

start transaction;
insert into test1 values(4,26,'C');
select * from test1;
update test1 set age=30 where id=1;
select * from test1;
rollback;

start transaction;
insert into test1 values(4,26,'C');
select * from test1;
update test1 set age=30 where id=1;
select * from test1;
commit;

set autocommit=off;
set autocommit=0;